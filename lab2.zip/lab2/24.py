print(6 & 3)

