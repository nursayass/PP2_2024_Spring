thisset = {"apple", "banana", "cherry", "apple"}

print(thisset)