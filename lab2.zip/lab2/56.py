thislist = ["apple", "banana", "cherry"]
[print(x) for x in thislist]