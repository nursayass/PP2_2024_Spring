list1 = ["abc", 34, True, 40, "male"]
print(list1)