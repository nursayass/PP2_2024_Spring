def my_function(x):
  return 5 * x

print(my_function(3))
print(my_function(5))
print(my_function(9))