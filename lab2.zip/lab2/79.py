thistuple = ("apple", "banana", "cherry")
print(thistuple)
