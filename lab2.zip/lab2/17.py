x = 5
y = 3

print(x != y)

# returns True because 5 is not equal to 3
