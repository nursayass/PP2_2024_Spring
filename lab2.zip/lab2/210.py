cars = ["Ford", "Volvo", "BMW"]

for x in cars:
  print(x)
