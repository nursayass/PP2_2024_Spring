thisset = {"apple", "banana", "cherry"}

x = thisset.pop()

print(x)

print(thisset)