print(bool("abc"))
print(bool(123))
print(bool(["apple", "cherry", "banana"]))