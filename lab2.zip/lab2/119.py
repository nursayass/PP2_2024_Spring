thisset = {"apple", "banana", "cherry"}

thisset.discard("banana")

print(thisset)