def myfunc(n):
  return lambda a : a * n