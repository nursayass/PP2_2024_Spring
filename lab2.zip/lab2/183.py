for x in range(2, 30, 3):
  print(x)