a = 33
b = 200
if not a > b:
  print("a is NOT greater than b")