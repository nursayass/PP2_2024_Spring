cars = ["Ford", "Volvo", "BMW"]

print(cars)
