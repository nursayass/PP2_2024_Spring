thistuple = ("apple", "banana", "cherry")
y = ("orange",)
thistuple += y

print(thistuple)