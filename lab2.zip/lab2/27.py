thislist = ["apple", "banana", "cherry", "apple", "cherry"]
print(thislist)
