cars = ["Ford", "Volvo", "BMW"]

cars.pop(1)

print(cars)
