x = 5
y = 3

print(x == y)

# returns False because 5 is not equal to 3
