mytuple = ("apple", "banana", "cherry")
print(type(mytuple))