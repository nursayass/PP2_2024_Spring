thisset = {"apple", "banana", "cherry"}

for x in thisset:
  print(x)
