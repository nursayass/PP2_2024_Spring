thislist = ["apple", "banana", "cherry"]
del thislist[0]
print(thislist)