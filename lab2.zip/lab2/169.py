a = 200
b = 33
c = 500
if a > b or a > c:
  print("At least one of the conditions is True")