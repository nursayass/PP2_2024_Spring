x = ["apple", "banana"]

print("banana" in x)

# returns True because a sequence with the value "banana" is in the list
