thisset = set(("apple", "banana", "cherry")) # note the double round-brackets
print(thisset)
