def myFunction() :
  return True

print(myFunction())