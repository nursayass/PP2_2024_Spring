for x in [0, 1, 2]:
  pass