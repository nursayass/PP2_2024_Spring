fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)
