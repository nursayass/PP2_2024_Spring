newlist = [x for x in range(10) if x < 5]

print(newlist)
