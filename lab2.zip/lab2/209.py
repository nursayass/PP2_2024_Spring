cars = ["Ford", "Volvo", "BMW"]

x = len(cars)

print(x)
