x = 5

print(x)
