thislist = ["apple", "banana", "cherry"]
thislist[1] = "blackcurrant"
print(thislist)
