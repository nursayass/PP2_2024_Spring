thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)