cars = ["Ford", "Volvo", "BMW"]

cars.remove("Volvo")

print(cars)
