thislist = ["apple", "banana", "cherry"]
mylist = list(thislist)
print(mylist)