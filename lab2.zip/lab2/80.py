thistuple = ("apple", "banana", "cherry", "apple", "cherry")
print(thistuple)
