cars = ["Ford", "Volvo", "BMW"]

cars[0] = "Toyota"

print(cars)
