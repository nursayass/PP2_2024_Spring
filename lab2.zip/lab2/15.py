x = 5

x += 3

print(x)
