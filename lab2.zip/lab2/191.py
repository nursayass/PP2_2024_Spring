def my_function(fname, lname):
  print(fname + " " + lname)

my_function("Emil", "Refsnes")