cars = ["Ford", "Volvo", "BMW"]

x = cars[0]

print(x)
