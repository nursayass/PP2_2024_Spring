myset = {"apple", "banana", "cherry"}
print(type(myset))