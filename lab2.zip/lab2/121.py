thisset = {"apple", "banana", "cherry"}

thisset.clear()

print(thisset)