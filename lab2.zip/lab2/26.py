thislist = ["apple", "banana", "cherry"]
print(thislist)