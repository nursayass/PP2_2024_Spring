thistuple = ("apple", "banana", "cherry")
for x in thistuple:
  print(x)
