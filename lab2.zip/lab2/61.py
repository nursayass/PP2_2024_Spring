newlist = [x for x in range(10)]
print(newlist)
