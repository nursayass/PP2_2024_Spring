thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.sort()
print(thislist)